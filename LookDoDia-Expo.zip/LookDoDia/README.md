# 📱 Look do Dia — Expo App

Assistente inteligente de moda com clima real e sugestões por IA.

---

## 🚀 Como rodar no celular

### 1. Pré-requisitos
- [Node.js 18+](https://nodejs.org)
- [Expo Go](https://expo.dev/go) instalado no celular (iOS ou Android)

### 2. Instalar dependências
```bash
cd LookDoDia
npm install
```

### 3. Adicionar as fontes
Crie a pasta `assets/fonts/` e adicione os arquivos:
- `CormorantGaramond-Light.ttf`
- `CormorantGaramond-LightItalic.ttf`
- `DMSans-Regular.ttf`
- `DMSans-Medium.ttf`

Baixe gratuitamente no [Google Fonts](https://fonts.google.com):
- [Cormorant Garamond](https://fonts.google.com/specimen/Cormorant+Garamond)
- [DM Sans](https://fonts.google.com/specimen/DM+Sans)

### 4. Iniciar o projeto
```bash
npm start
```

### 5. Abrir no celular
- Abra o app **Expo Go** no celular
- Escaneie o QR Code exibido no terminal
- O app abrirá instantaneamente ✨

---

## 📦 Gerar APK (Android) para instalar sem loja

```bash
# Instalar EAS CLI
npm install -g eas-cli

# Login na conta Expo (gratuita)
eas login

# Configurar o build
eas build:configure

# Gerar APK para Android
eas build --platform android --profile preview
```

Após o build (~5 min), você receberá um link para baixar o `.apk` diretamente.

---

## 🍎 Publicar na App Store / Play Store

```bash
# Build de produção
eas build --platform all

# Enviar para revisão
eas submit --platform android
eas submit --platform ios
```

---

## 🗂 Estrutura do Projeto

```
LookDoDia/
├── app/
│   └── _layout.tsx        # Entry point + navegação
├── components/
│   ├── UI.tsx             # Componentes compartilhados
│   ├── Onboarding.tsx     # Tela de onboarding (5 passos)
│   ├── HomeScreen.tsx     # Tela principal + clima
│   ├── LooksResult.tsx    # Resultado dos looks (Claude API)
│   ├── WardrobeScreen.tsx # Guarda-roupa virtual
│   ├── FavoritesScreen.tsx# Favoritos e histórico
│   ├── PlannerScreen.tsx  # Planner semanal
│   └── ProfileScreen.tsx  # Perfil do usuário
├── constants/
│   ├── index.ts           # Cores, categorias, tokens de design
│   └── types.ts           # Tipos TypeScript
├── store/
│   ├── storage.ts         # AsyncStorage (persistência local)
│   ├── weather.ts         # API Open-Meteo (clima real)
│   └── claude.ts          # Anthropic API (geração de looks)
├── assets/
│   └── fonts/             # Fontes (adicionar manualmente)
├── app.json               # Config Expo
└── package.json
```

---

## ⚙️ Tecnologias

| Tecnologia | Uso |
|---|---|
| **Expo 51** | Framework mobile |
| **React Native** | Componentes nativos |
| **Expo Router** | Navegação |
| **AsyncStorage** | Persistência local |
| **Open-Meteo API** | Clima em tempo real (gratuito) |
| **Claude API** | Geração inteligente de looks |
| **TypeScript** | Tipagem |

---

## 🔮 Próximos passos

- [ ] Upload de fotos reais das peças (expo-image-picker)
- [ ] Notificação matinal "Look do dia"
- [ ] Compartilhar look como imagem
- [ ] Modo offline com looks salvos
- [ ] Integração com previsão do tempo 7 dias
- [ ] Sugestão de compras para peças faltantes
