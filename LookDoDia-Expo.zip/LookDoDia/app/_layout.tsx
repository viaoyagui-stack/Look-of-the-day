import React, { useState, useEffect, useCallback } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Platform } from 'react-native';
import { useFonts } from 'expo-font';
import * as SplashScreen from 'expo-splash-screen';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';

import { G } from '../constants';
import { Profile, Piece, FavoriteEntry, HistoryEntry, Weather } from '../constants/types';
import { loadData, saveData, removeData } from '../store/storage';
import { fetchWeather } from '../store/weather';

import Onboarding from '../components/Onboarding';
import HomeScreen from '../components/HomeScreen';
import LooksResult from '../components/LooksResult';
import WardrobeScreen from '../components/WardrobeScreen';
import FavoritesScreen from '../components/FavoritesScreen';
import PlannerScreen from '../components/PlannerScreen';
import ProfileScreen from '../components/ProfileScreen';

SplashScreen.preventAutoHideAsync();

type Tab = 'home' | 'wardrobe' | 'favs' | 'planner' | 'profile';

const NAV_ITEMS: { id: Tab; icon: string; label: string }[] = [
  { id: 'home',     icon: '🏠', label: 'Início'    },
  { id: 'wardrobe', icon: '👗', label: 'Closet'    },
  { id: 'favs',     icon: '❤️', label: 'Favoritos' },
  { id: 'planner',  icon: '📅', label: 'Planner'   },
  { id: 'profile',  icon: '👤', label: 'Perfil'    },
];

export default function RootLayout() {
  const [fontsLoaded] = useFonts({
    'CormorantGaramond': require('../assets/fonts/CormorantGaramond-Light.ttf'),
    'CormorantGaramond-Italic': require('../assets/fonts/CormorantGaramond-LightItalic.ttf'),
    'DMSans': require('../assets/fonts/DMSans-Regular.ttf'),
    'DMSans-Medium': require('../assets/fonts/DMSans-Medium.ttf'),
  });

  const [profile,   setProfile]   = useState<Profile | null>(null);
  const [wardrobe,  setWardrobe]  = useState<Piece[]>([]);
  const [favorites, setFavorites] = useState<FavoriteEntry[]>([]);
  const [history,   setHistory]   = useState<HistoryEntry[]>([]);
  const [planner,   setPlanner]   = useState<Record<string, string>>({});
  const [weather,   setWeather]   = useState<Weather | null>(null);
  const [tab,       setTab]       = useState<Tab>('home');
  const [lookOccasion, setLookOccasion] = useState<string | null>(null);
  const [ready,     setReady]     = useState(false);

  // Load persisted data
  useEffect(() => {
    (async () => {
      const [p, w, f, h, pl] = await Promise.all([
        loadData<Profile | null>('profile', null),
        loadData<Piece[]>('wardrobe', []),
        loadData<FavoriteEntry[]>('favorites', []),
        loadData<HistoryEntry[]>('history', []),
        loadData<Record<string, string>>('planner', {}),
      ]);
      setProfile(p);
      setWardrobe(w);
      setFavorites(f);
      setHistory(h);
      setPlanner(pl);
      setReady(true);
    })();
  }, []);

  // Fetch weather when profile city changes
  useEffect(() => {
    if (profile?.city) {
      fetchWeather(profile.city).then(w => { if (w) setWeather(w); });
    }
  }, [profile?.city]);

  const onLayoutRootView = useCallback(async () => {
    if (fontsLoaded && ready) await SplashScreen.hideAsync();
  }, [fontsLoaded, ready]);

  if (!fontsLoaded || !ready) return null;

  const onCompleteOnboarding = async (p: Profile) => {
    await saveData('profile', p);
    setProfile(p);
  };

  const updateWardrobe = async (w: Piece[]) => {
    setWardrobe(w);
    await saveData('wardrobe', w);
  };

  const updatePlanner = async (p: Record<string, string>) => {
    setPlanner(p);
    await saveData('planner', p);
  };

  const onSaveFav = async (entry: FavoriteEntry) => {
    const updated = [...favorites, entry];
    setFavorites(updated);
    await saveData('favorites', updated);
  };

  const onSaveHistory = async (entry: HistoryEntry) => {
    const updated = [...history, entry];
    setHistory(updated);
    await saveData('history', updated);
  };

  const onGenerateLook = (occasion: string) => {
    setLookOccasion(occasion);
  };

  const onBackFromLooks = () => {
    setLookOccasion(null);
  };

  const onEditProfile = async () => {
    await removeData('profile');
    setProfile(null);
  };

  if (!profile) {
    return (
      <SafeAreaProvider>
        <StatusBar style="light" />
        <View style={{ flex: 1 }} onLayout={onLayoutRootView}>
          <Onboarding onComplete={onCompleteOnboarding} />
        </View>
      </SafeAreaProvider>
    );
  }

  return (
    <SafeAreaProvider>
      <StatusBar style="light" />
      <View style={{ flex: 1 }} onLayout={onLayoutRootView}>

        {/* Looks result (full screen overlay) */}
        {lookOccasion ? (
          <LooksResult
            profile={profile}
            wardrobe={wardrobe}
            occasion={lookOccasion}
            weather={weather}
            onBack={onBackFromLooks}
            onSaveFav={onSaveFav}
            onSaveHistory={onSaveHistory}
          />
        ) : (
          <>
            {tab === 'home' && (
              <HomeScreen
                profile={profile}
                weather={weather}
                wardrobeCount={wardrobe.length}
                onGenerateLook={onGenerateLook}
                onNavigateWardrobe={() => setTab('wardrobe')}
              />
            )}
            {tab === 'wardrobe' && (
              <WardrobeScreen wardrobe={wardrobe} setWardrobe={updateWardrobe} />
            )}
            {tab === 'favs' && (
              <FavoritesScreen favorites={favorites} history={history} />
            )}
            {tab === 'planner' && (
              <PlannerScreen plan={planner} setPlan={updatePlanner} />
            )}
            {tab === 'profile' && (
              <ProfileScreen profile={profile} onEdit={onEditProfile} />
            )}

            {/* Bottom Nav */}
            <View style={styles.nav}>
              {NAV_ITEMS.map(n => (
                <TouchableOpacity
                  key={n.id}
                  style={styles.navItem}
                  onPress={() => setTab(n.id)}
                >
                  <Text style={styles.navIcon}>{n.icon}</Text>
                  <Text style={[styles.navLabel, tab === n.id && styles.navLabelActive]}>
                    {n.label}
                  </Text>
                  {tab === n.id && <View style={styles.navDot} />}
                </TouchableOpacity>
              ))}
            </View>
          </>
        )}
      </View>
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  nav: {
    flexDirection: 'row',
    backgroundColor: 'rgba(255,255,255,0.97)',
    borderTopWidth: 1,
    borderTopColor: G.border,
    paddingTop: 8,
    paddingBottom: Platform.OS === 'ios' ? 24 : 10,
  },
  navItem: { flex: 1, alignItems: 'center', gap: 2, paddingVertical: 4 },
  navIcon: { fontSize: 22 },
  navLabel: { fontSize: 10, color: G.muted, fontFamily: 'DMSans', letterSpacing: 0.3 },
  navLabelActive: { color: G.accent, fontWeight: '500' },
  navDot: {
    width: 4, height: 4, borderRadius: 2,
    backgroundColor: G.warm, marginTop: 2,
  },
});
