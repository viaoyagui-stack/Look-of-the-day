export interface Profile {
  name: string;
  city: string;
  style: string;
  sensitivity: string;
  favColors: string[];
  avoidColors: string[];
}

export interface Piece {
  id: string;
  name: string;
  category: string;
  color: string;
  formality: string;
  climate: string[];
}

export interface LookPiece {
  id: string | null;
  nome: string;
  cor: string;
}

export interface Look {
  numero: number;
  top: LookPiece;
  bottom: LookPiece;
  shoes: LookPiece;
  accessory: LookPiece | null;
  motivo: string;
}

export interface FavoriteEntry {
  occasion: string;
  look: Look;
  date: string;
}

export interface HistoryEntry {
  occasion: string;
  looks: Look[];
  date: string;
}

export interface Weather {
  temp: number;
  code: number;
  wind: number;
  rain: boolean;
  desc: string;
  city: string;
}

export interface PlannerDay {
  [dateKey: string]: string;
}
