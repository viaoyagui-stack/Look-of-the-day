// ─── DESIGN TOKENS ────────────────────────────────────────────────────────────
export const G = {
  bg:      '#F5F2EE',
  card:    '#FFFFFF',
  accent:  '#1C1C1E',
  soft:    '#F0EDE8',
  border:  '#E8E2D9',
  muted:   '#9B9589',
  warm:    '#C4A882',
  sand:    '#E8DDD0',
  error:   '#EF4444',
  blue:    '#3B82F6',
};

export const FONT = {
  serif:  'CormorantGaramond',
  sans:   'DMSans',
};

// ─── DATA CONSTANTS ───────────────────────────────────────────────────────────
export const CATEGORIES = [
  'Camiseta','Camisa','Blusa','Calça','Short',
  'Saia','Vestido','Casaco','Tênis','Sapato','Sandália','Acessório',
];

export const FORMALITY = ['Casual','Smart Casual','Social','Formal'];

export const CLIMATES = ['Calor','Ameno','Frio','Chuva'];

export const STYLES = ['Casual','Elegante','Social','Esportivo','Minimalista','Streetwear'];

export const SENSITIVITIES = [
  'Sinto muito frio',
  'Sinto frio normal',
  'Sinto calor normal',
  'Sinto muito calor',
];

export const OCCASIONS = [
  { id: 'escritorio',    label: 'Escritório',        icon: '💼' },
  { id: 'academia',      label: 'Academia',           icon: '🏋️' },
  { id: 'passear',       label: 'Passear',            icon: '🚶' },
  { id: 'jantar',        label: 'Jantar',             icon: '🍽️' },
  { id: 'faculdade',     label: 'Faculdade',          icon: '🎓' },
  { id: 'evento',        label: 'Evento Social',      icon: '🎉' },
  { id: 'casa',          label: 'Trabalhar em Casa',  icon: '🏠' },
  { id: 'viagem',        label: 'Viagem',             icon: '✈️' },
  { id: 'personalizado', label: 'Personalizado',      icon: '✏️' },
];

export const COLORS = [
  'Branco','Preto','Cinza','Bege','Azul','Azul Marinho',
  'Verde','Vermelho','Amarelo','Rosa','Laranja','Roxo',
  'Marrom','Khaki','Estampado','Colorido',
];

export const COLOR_HEX: Record<string, string> = {
  'Branco':      '#F8F8F8',
  'Preto':       '#1a1a1a',
  'Cinza':       '#9CA3AF',
  'Bege':        '#D4B896',
  'Azul':        '#3B82F6',
  'Azul Marinho':'#1E3A5F',
  'Verde':       '#16A34A',
  'Vermelho':    '#DC2626',
  'Amarelo':     '#FBBF24',
  'Rosa':        '#F472B6',
  'Laranja':     '#F97316',
  'Roxo':        '#9333EA',
  'Marrom':      '#92400E',
  'Khaki':       '#BDB76B',
  'Estampado':   '#F472B6',
  'Colorido':    '#60a5fa',
};

export const CAT_EMOJI: Record<string, string> = {
  'Camiseta':'👕','Camisa':'👔','Blusa':'👚','Calça':'👖',
  'Short':'🩳','Saia':'👗','Vestido':'👗','Casaco':'🧥',
  'Tênis':'👟','Sapato':'👞','Sandália':'🥿','Acessório':'💍',
};

export const WEATHER_CODES: Record<number, string> = {
  0:'☀️ Céu limpo', 1:'🌤 Predominantemente limpo', 2:'⛅ Parcialmente nublado',
  3:'☁️ Nublado', 45:'🌫 Neblina', 51:'🌦 Garoa leve', 53:'🌦 Garoa moderada',
  61:'🌧 Chuva leve', 63:'🌧 Chuva moderada', 65:'🌧 Chuva forte',
  71:'❄️ Neve leve', 80:'🌦 Pancadas de chuva', 81:'⛈ Chuva intensa',
  95:'⛈ Tempestade',
};

export const DAYS = ['Dom','Seg','Ter','Qua','Qui','Sex','Sáb'];
