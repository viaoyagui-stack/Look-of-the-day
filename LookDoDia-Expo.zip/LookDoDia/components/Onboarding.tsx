import React, { useState } from 'react';
import {
  View, Text, TextInput, StyleSheet, ScrollView,
  TouchableOpacity, KeyboardAvoidingView, Platform,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { G, STYLES, SENSITIVITIES, COLORS } from '../constants';
import { ChipGroup, Button, SectionLabel } from '../components/UI';
import { Profile } from '../constants/types';

const TOTAL_STEPS = 5;

interface OnboardingProps {
  onComplete: (profile: Profile) => void;
}

export default function Onboarding({ onComplete }: OnboardingProps) {
  const insets = useSafeAreaInsets();
  const [step, setStep] = useState(0);
  const [form, setForm] = useState<Profile>({
    name: '', city: '', style: '', sensitivity: '',
    favColors: [], avoidColors: [],
  });

  const set = (k: keyof Profile, v: any) => setForm(p => ({ ...p, [k]: v }));

  const canNext = [
    form.name.trim().length > 0,
    form.city.trim().length > 0,
    !!form.style,
    !!form.sensitivity,
    form.favColors.length > 0,
  ][step];

  const next = () => {
    if (step < TOTAL_STEPS - 1) setStep(s => s + 1);
    else onComplete(form);
  };

  const progress = ((step + 1) / TOTAL_STEPS) * 100;

  return (
    <KeyboardAvoidingView
      style={{ flex: 1 }}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      {/* Hero */}
      <LinearGradient colors={[G.accent, '#2c2c2e']} style={[styles.hero, { paddingTop: insets.top + 32 }]}>
        <Text style={styles.logo}>Look do Dia</Text>
        <Text style={styles.heroTitle}>{'Seu stylist\npessoal'}</Text>
        <Text style={styles.heroSub}>Looks perfeitos para cada momento</Text>
      </LinearGradient>

      <ScrollView style={styles.body} contentContainerStyle={{ paddingBottom: 120 }}>
        {/* Progress */}
        <View style={styles.progressBar}>
          <View style={[styles.progressFill, { width: `${progress}%` as any }]} />
        </View>

        {step === 0 && (
          <View>
            <Text style={styles.stepLabel}>Passo 1 de {TOTAL_STEPS}</Text>
            <Text style={styles.stepTitle}>{'Como você\nse chama?'}</Text>
            <TextInput
              style={styles.input}
              placeholder="Seu nome"
              placeholderTextColor={G.muted}
              value={form.name}
              onChangeText={v => set('name', v)}
            />
          </View>
        )}

        {step === 1 && (
          <View>
            <Text style={styles.stepLabel}>Passo 2 de {TOTAL_STEPS}</Text>
            <Text style={styles.stepTitle}>{'Qual é\na sua cidade?'}</Text>
            <TextInput
              style={styles.input}
              placeholder="Ex: São Paulo"
              placeholderTextColor={G.muted}
              value={form.city}
              onChangeText={v => set('city', v)}
            />
            <Text style={styles.hint}>Usamos para buscar o clima em tempo real.</Text>
          </View>
        )}

        {step === 2 && (
          <View>
            <Text style={styles.stepLabel}>Passo 3 de {TOTAL_STEPS}</Text>
            <Text style={styles.stepTitle}>{'Qual é\no seu estilo?'}</Text>
            <ChipGroup options={STYLES} value={form.style} onChange={v => set('style', v)} />
          </View>
        )}

        {step === 3 && (
          <View>
            <Text style={styles.stepLabel}>Passo 4 de {TOTAL_STEPS}</Text>
            <Text style={styles.stepTitle}>{'Sua sensibilidade\nao clima?'}</Text>
            <ChipGroup options={SENSITIVITIES} value={form.sensitivity} onChange={v => set('sensitivity', v)} />
          </View>
        )}

        {step === 4 && (
          <View>
            <Text style={styles.stepLabel}>Passo 5 de {TOTAL_STEPS}</Text>
            <Text style={styles.stepTitle}>{'Suas cores\nfavoritas?'}</Text>
            <SectionLabel>Cores que você ama</SectionLabel>
            <ChipGroup options={COLORS} value={form.favColors} onChange={v => set('favColors', v)} multi />
            <View style={{ marginTop: 8 }}>
              <SectionLabel>Cores que você evita</SectionLabel>
              <ChipGroup options={COLORS} value={form.avoidColors} onChange={v => set('avoidColors', v)} multi warn />
            </View>
          </View>
        )}

        <View style={styles.actions}>
          {step > 0 && (
            <Button label="Voltar" variant="outline" onPress={() => setStep(s => s - 1)} style={{ flex: 1 }} />
          )}
          <Button
            label={step < TOTAL_STEPS - 1 ? 'Continuar' : 'Começar ✨'}
            onPress={next}
            disabled={!canNext}
            style={{ flex: 1 }}
          />
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  hero: { paddingHorizontal: 32, paddingBottom: 40 },
  logo: {
    fontFamily: 'CormorantGaramond', fontSize: 13,
    letterSpacing: 4, color: G.warm, marginBottom: 24,
    textTransform: 'uppercase',
  },
  heroTitle: {
    fontFamily: 'CormorantGaramond', fontSize: 42,
    fontWeight: '300', color: '#fff', lineHeight: 50, marginBottom: 12,
  },
  heroSub: { fontSize: 14, color: 'rgba(255,255,255,0.55)' },

  body: { flex: 1, backgroundColor: G.bg, paddingHorizontal: 24, paddingTop: 32 },

  progressBar: { height: 2, backgroundColor: G.border, borderRadius: 2, marginBottom: 32 },
  progressFill: { height: 2, backgroundColor: G.warm, borderRadius: 2 },

  stepLabel: {
    fontSize: 11, letterSpacing: 3, textTransform: 'uppercase',
    color: G.warm, marginBottom: 8, fontFamily: 'DMSans',
  },
  stepTitle: {
    fontFamily: 'CormorantGaramond', fontSize: 28,
    fontWeight: '400', color: G.accent, marginBottom: 24, lineHeight: 36,
  },

  input: {
    borderWidth: 1.5, borderColor: G.border, borderRadius: 12,
    paddingHorizontal: 16, paddingVertical: 14,
    fontSize: 15, backgroundColor: G.card, color: G.accent,
    fontFamily: 'DMSans',
  },
  hint: { fontSize: 12, color: G.muted, marginTop: 8 },

  actions: { flexDirection: 'row', gap: 12, marginTop: 32 },
});
