import React, { useState } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity, StyleSheet, Modal,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { G, DAYS, OCCASIONS } from '../constants';

interface PlannerProps {
  plan: Record<string, string>;
  setPlan: (p: Record<string, string>) => void;
}

export default function PlannerScreen({ plan, setPlan }: PlannerProps) {
  const insets = useSafeAreaInsets();
  const [editing, setEditing] = useState<string | null>(null);

  const today = new Date();
  const startOfWeek = new Date(today);
  startOfWeek.setDate(today.getDate() - today.getDay());

  const setDay = (key: string, occ: string) => {
    setPlan({ ...plan, [key]: occ });
    setEditing(null);
  };

  const removeDay = (key: string) => {
    const updated = { ...plan };
    delete updated[key];
    setPlan(updated);
    setEditing(null);
  };

  const days = DAYS.map((d, i) => {
    const date = new Date(startOfWeek);
    date.setDate(startOfWeek.getDate() + i);
    return { label: d, date, key: date.toDateString() };
  });

  return (
    <View style={{ flex: 1, backgroundColor: G.bg }}>
      <LinearGradient
        colors={[G.accent, '#2c2c2e']}
        style={[styles.header, { paddingTop: insets.top + 16 }]}
      >
        <Text style={styles.headerTitle}>Planner semanal</Text>
        <Text style={styles.headerSub}>Planeje seus looks da semana</Text>
      </LinearGradient>

      <ScrollView horizontal contentContainerStyle={styles.weekRow} showsHorizontalScrollIndicator={false}>
        {days.map(({ label, date, key }) => {
          const isToday = key === today.toDateString();
          const occ = plan[key];
          const occObj = occ ? OCCASIONS.find(o => o.label === occ || o.id === occ) : null;

          return (
            <View key={key} style={styles.dayCol}>
              <Text style={[styles.dayLabel, isToday && { color: G.warm }]}>{label}</Text>
              <Text style={[styles.dayNum, isToday && { color: G.warm, fontWeight: '600' }]}>
                {date.getDate()}
              </Text>
              <TouchableOpacity
                style={[styles.daySlot, occ && styles.daySlotFilled, isToday && { borderColor: G.warm }]}
                onPress={() => setEditing(key)}
              >
                {occ ? (
                  <View style={{ alignItems: 'center' }}>
                    <Text style={{ fontSize: 20, marginBottom: 4 }}>{occObj?.icon ?? '📅'}</Text>
                    <Text style={styles.slotText}>{occ}</Text>
                  </View>
                ) : (
                  <Text style={{ fontSize: 20, opacity: 0.3 }}>+</Text>
                )}
              </TouchableOpacity>
            </View>
          );
        })}
      </ScrollView>

      <View style={styles.tipCard}>
        <Text style={styles.tipLabel}>💡 Como usar</Text>
        <Text style={styles.tipText}>
          Toque em qualquer dia para adicionar uma ocasião. Na tela inicial, gere looks para a ocasião planejada.
        </Text>
      </View>

      {/* Picker Modal */}
      <Modal visible={!!editing} transparent animationType="slide">
        <TouchableOpacity style={styles.overlay} activeOpacity={1} onPress={() => setEditing(null)}>
          <TouchableOpacity activeOpacity={1} style={styles.sheet}>
            <View style={styles.sheetHandle} />
            <Text style={styles.sheetTitle}>Escolha a ocasião</Text>
            <ScrollView>
              {OCCASIONS.map(o => (
                <TouchableOpacity
                  key={o.id}
                  style={styles.occRow}
                  onPress={() => editing && setDay(editing, o.label)}
                >
                  <Text style={{ fontSize: 24 }}>{o.icon}</Text>
                  <Text style={styles.occLabel}>{o.label}</Text>
                </TouchableOpacity>
              ))}
              {editing && plan[editing] && (
                <TouchableOpacity style={styles.removeRow} onPress={() => editing && removeDay(editing)}>
                  <Text style={styles.removeText}>🗑 Remover ocasião</Text>
                </TouchableOpacity>
              )}
            </ScrollView>
          </TouchableOpacity>
        </TouchableOpacity>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  header: { paddingHorizontal: 24, paddingBottom: 24 },
  headerTitle: { fontFamily: 'CormorantGaramond', fontSize: 32, fontWeight: '300', color: '#fff' },
  headerSub: { fontSize: 13, color: 'rgba(255,255,255,0.5)', marginTop: 4 },

  weekRow: { padding: 16, gap: 10, flexDirection: 'row' },
  dayCol: { width: 90, alignItems: 'center' },
  dayLabel: { fontSize: 10, color: G.muted, letterSpacing: 1, textTransform: 'uppercase', marginBottom: 4, fontFamily: 'DMSans' },
  dayNum: { fontSize: 13, color: G.muted, marginBottom: 8, fontFamily: 'DMSans' },
  daySlot: {
    width: 80, minHeight: 120, borderRadius: 14,
    borderWidth: 1.5, borderStyle: 'dashed', borderColor: G.border,
    backgroundColor: G.card, alignItems: 'center', justifyContent: 'center',
    padding: 8,
  },
  daySlotFilled: { borderStyle: 'solid', backgroundColor: G.soft },
  slotText: { fontSize: 9, color: G.muted, textAlign: 'center', lineHeight: 13, fontFamily: 'DMSans' },

  tipCard: { margin: 16, backgroundColor: G.soft, borderRadius: 16, padding: 20 },
  tipLabel: { fontSize: 11, color: G.muted, letterSpacing: 1, textTransform: 'uppercase', marginBottom: 8, fontFamily: 'DMSans' },
  tipText: { fontSize: 13, color: G.accent, lineHeight: 20, fontFamily: 'DMSans' },

  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  sheet: {
    backgroundColor: G.bg, borderTopLeftRadius: 24, borderTopRightRadius: 24,
    padding: 24, maxHeight: '60%',
  },
  sheetHandle: { width: 40, height: 4, backgroundColor: G.border, borderRadius: 2, alignSelf: 'center', marginBottom: 20 },
  sheetTitle: { fontFamily: 'CormorantGaramond', fontSize: 22, color: G.accent, marginBottom: 16 },
  occRow: {
    flexDirection: 'row', alignItems: 'center', gap: 14,
    paddingVertical: 14, borderBottomWidth: 1, borderBottomColor: G.border,
  },
  occLabel: { fontSize: 15, color: G.accent, fontFamily: 'DMSans' },
  removeRow: { paddingVertical: 16, alignItems: 'center' },
  removeText: { color: '#EF4444', fontSize: 14, fontFamily: 'DMSans' },
});
