import React, { useEffect, useState } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity, StyleSheet,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { G } from '../constants';
import { ColorSwatch, LoadingView, EmptyState, Button } from '../components/UI';
import { generateLooks } from '../store/claude';
import { Profile, Piece, Weather, Look, FavoriteEntry, HistoryEntry } from '../constants/types';

interface LooksResultProps {
  profile: Profile;
  wardrobe: Piece[];
  occasion: string;
  weather: Weather | null;
  onBack: () => void;
  onSaveFav: (entry: FavoriteEntry) => void;
  onSaveHistory: (entry: HistoryEntry) => void;
}

export default function LooksResult({
  profile, wardrobe, occasion, weather, onBack, onSaveFav, onSaveHistory,
}: LooksResultProps) {
  const insets = useSafeAreaInsets();
  const [data, setData] = useState<{ looks: Look[] } | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState<Record<number, boolean>>({});

  useEffect(() => {
    generateLooks(profile, wardrobe, occasion, weather)
      .then(d => {
        setData(d);
        onSaveHistory({ occasion, looks: d.looks, date: new Date().toISOString() });
      })
      .catch(() => setError('Não foi possível gerar os looks. Verifique sua conexão.'));
  }, []);

  const getPiece = (item: any) => {
    if (!item?.id) return item;
    return wardrobe.find(w => w.id === item.id) || item;
  };

  const saveFav = (look: Look, idx: number) => {
    onSaveFav({ occasion, look, date: new Date().toISOString() });
    setSaved(p => ({ ...p, [idx]: true }));
  };

  if (error) return (
    <View style={{ flex: 1, backgroundColor: G.bg }}>
      <View style={[styles.header, { paddingTop: insets.top + 16 }]}>
        <TouchableOpacity onPress={onBack} style={styles.backBtn}>
          <Text style={styles.backBtnText}>←</Text>
        </TouchableOpacity>
      </View>
      <EmptyState icon="😔" title="Ops!" subtitle={error} />
    </View>
  );

  if (!data) return (
    <View style={{ flex: 1, backgroundColor: G.bg }}>
      <View style={[styles.header, { paddingTop: insets.top + 16 }]}>
        <TouchableOpacity onPress={onBack} style={styles.backBtn}>
          <Text style={styles.backBtnText}>←</Text>
        </TouchableOpacity>
      </View>
      <LoadingView text="Montando seus looks…" />
    </View>
  );

  return (
    <ScrollView style={{ flex: 1, backgroundColor: G.bg }} contentContainerStyle={{ paddingBottom: 40 }}>
      <LinearGradient
        colors={[G.accent, '#2c2c2e']}
        style={[styles.header, { paddingTop: insets.top + 16 }]}
      >
        <TouchableOpacity onPress={onBack} style={styles.backBtn}>
          <Text style={styles.backBtnText}>←</Text>
        </TouchableOpacity>
        <View style={{ flex: 1 }}>
          <Text style={styles.headerSub}>{occasion}</Text>
          <Text style={styles.headerTitle}>Seus looks de hoje</Text>
        </View>
      </LinearGradient>

      <View style={{ paddingTop: 16 }}>
        {data.looks.map((look, i) => {
          const top  = getPiece(look.top);
          const bot  = getPiece(look.bottom);
          const shoe = getPiece(look.shoes);
          const acc  = look.accessory ? getPiece(look.accessory) : null;
          const pieces = [top, bot, shoe, ...(acc ? [acc] : [])].filter(Boolean);

          return (
            <View key={i} style={styles.lookCard}>
              <Text style={styles.lookNum}>Look {look.numero}</Text>

              <View style={styles.piecesRow}>
                {pieces.map((p: any, j: number) => (
                  <View key={j} style={styles.pieceChip}>
                    <ColorSwatch color={p.color} size={10} />
                    <Text style={styles.pieceChipText}>{p.nome || p.name}</Text>
                  </View>
                ))}
              </View>

              <View style={styles.divider} />
              <Text style={styles.motivo}>{look.motivo}</Text>

              <TouchableOpacity
                style={[styles.favBtn, saved[i] && styles.favBtnSaved]}
                onPress={() => saveFav(look, i)}
              >
                <Text style={styles.favBtnText}>
                  {saved[i] ? '❤️ Salvo' : '🤍 Favoritar'}
                </Text>
              </TouchableOpacity>
            </View>
          );
        })}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  header: {
    paddingHorizontal: 20, paddingBottom: 24,
    flexDirection: 'row', alignItems: 'center', gap: 16,
  },
  backBtn: {
    width: 36, height: 36, borderRadius: 18,
    backgroundColor: 'rgba(255,255,255,0.15)',
    alignItems: 'center', justifyContent: 'center',
  },
  backBtnText: { color: '#fff', fontSize: 18 },
  headerSub: { fontSize: 11, letterSpacing: 3, color: 'rgba(255,255,255,0.5)', textTransform: 'uppercase', marginBottom: 2 },
  headerTitle: { fontFamily: 'CormorantGaramond', fontSize: 22, fontWeight: '300', color: '#fff' },

  lookCard: {
    backgroundColor: G.card, borderRadius: 20,
    marginHorizontal: 16, marginBottom: 16, padding: 20,
    borderWidth: 1, borderColor: G.border,
  },
  lookNum: { fontSize: 11, letterSpacing: 3, textTransform: 'uppercase', color: G.warm, marginBottom: 12, fontFamily: 'DMSans' },
  piecesRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 12 },
  pieceChip: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    backgroundColor: G.soft, borderRadius: 10,
    paddingHorizontal: 12, paddingVertical: 8,
  },
  pieceChipText: { fontSize: 12, color: G.accent, fontFamily: 'DMSans' },
  divider: { height: 1, backgroundColor: G.border, marginBottom: 12 },
  motivo: { fontSize: 13, color: G.muted, lineHeight: 20, marginBottom: 14, fontFamily: 'DMSans' },

  favBtn: {
    borderWidth: 1.5, borderColor: G.border, borderRadius: 10,
    paddingVertical: 10, alignItems: 'center',
  },
  favBtnSaved: { borderColor: '#F472B6', backgroundColor: '#FFF0F8' },
  favBtnText: { fontSize: 13, color: G.accent, fontFamily: 'DMSans', fontWeight: '500' },
});
