import React, { useState } from 'react';
import {
  View, Text, ScrollView, TextInput, TouchableOpacity, StyleSheet,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { G, OCCASIONS } from '../constants';
import { Button } from '../components/UI';
import { Profile, Weather } from '../constants/types';

interface HomeProps {
  profile: Profile;
  weather: Weather | null;
  wardrobeCount: number;
  onGenerateLook: (occasion: string) => void;
  onNavigateWardrobe: () => void;
}

export default function HomeScreen({
  profile, weather, wardrobeCount, onGenerateLook, onNavigateWardrobe,
}: HomeProps) {
  const insets = useSafeAreaInsets();
  const hour = new Date().getHours();
  const greeting = hour < 12 ? 'Bom dia' : hour < 18 ? 'Boa tarde' : 'Boa noite';
  const [selected, setSelected] = useState<string | null>(null);
  const [custom, setCustom] = useState('');

  const handleGenerate = () => {
    const occ =
      selected === 'personalizado'
        ? custom || 'Ocasião especial'
        : OCCASIONS.find(o => o.id === selected)?.label ?? selected ?? '';
    onGenerateLook(occ);
  };

  return (
    <ScrollView style={{ flex: 1, backgroundColor: G.bg }} contentContainerStyle={{ paddingBottom: 100 }}>
      {/* Header */}
      <LinearGradient
        colors={[G.accent, '#2c2c2e']}
        style={[styles.header, { paddingTop: insets.top + 24 }]}
      >
        <Text style={styles.greeting}>{greeting},</Text>
        <Text style={styles.name}>{profile.name}</Text>
      </LinearGradient>

      {/* Weather Card */}
      <View style={styles.weatherCard}>
        {weather ? (
          <>
            <Text style={{ fontSize: 40 }}>{weather.desc.split(' ')[0]}</Text>
            <Text style={styles.temp}>{weather.temp}°</Text>
            <View style={{ flex: 1 }}>
              <Text style={styles.weatherDesc}>{weather.desc.split(' ').slice(1).join(' ')}</Text>
              <Text style={styles.weatherCity}>{weather.city}</Text>
              {weather.wind > 0 && (
                <Text style={styles.weatherExtra}>💨 {weather.wind}km/h</Text>
              )}
              {weather.rain && (
                <Text style={[styles.weatherExtra, { color: G.blue }]}>🌧 Chuva</Text>
              )}
            </View>
          </>
        ) : (
          <Text style={{ color: G.muted, fontSize: 13 }}>Buscando clima de {profile.city}…</Text>
        )}
      </View>

      {/* Occasion Selector */}
      <View style={styles.section}>
        <Text style={styles.sectionSub}>O que você vai fazer hoje?</Text>
        <View style={styles.occasionGrid}>
          {OCCASIONS.map(o => (
            <TouchableOpacity
              key={o.id}
              style={[styles.occCard, selected === o.id && styles.occCardActive]}
              onPress={() => setSelected(o.id)}
            >
              <Text style={styles.occIcon}>{o.icon}</Text>
              <Text style={styles.occLabel}>{o.label}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {selected === 'personalizado' && (
          <TextInput
            style={styles.input}
            placeholder="Descreva a ocasião…"
            placeholderTextColor={G.muted}
            value={custom}
            onChangeText={setCustom}
          />
        )}

        {selected && (
          <Button label="✨ Gerar meus looks" onPress={handleGenerate} />
        )}
      </View>

      {/* Wardrobe Tip */}
      {wardrobeCount === 0 && (
        <View style={styles.tipCard}>
          <Text style={styles.tipTitle}>💡 Dica</Text>
          <Text style={styles.tipText}>
            Adicione peças ao seu guarda-roupa para receber sugestões personalizadas.
          </Text>
          <TouchableOpacity style={styles.tipBtn} onPress={onNavigateWardrobe}>
            <Text style={styles.tipBtnText}>Adicionar roupas →</Text>
          </TouchableOpacity>
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  header: { paddingHorizontal: 24, paddingBottom: 28 },
  greeting: { fontSize: 13, color: 'rgba(255,255,255,0.5)', letterSpacing: 1, marginBottom: 4 },
  name: { fontFamily: 'CormorantGaramond', fontSize: 32, fontWeight: '300', color: '#fff' },

  weatherCard: {
    margin: 16, marginTop: 20, backgroundColor: G.card,
    borderRadius: 20, padding: 20,
    flexDirection: 'row', alignItems: 'center', gap: 16,
    borderWidth: 1, borderColor: G.border,
  },
  temp: { fontFamily: 'CormorantGaramond', fontSize: 52, fontWeight: '300', lineHeight: 56 },
  weatherDesc: { fontSize: 14, color: G.muted, marginBottom: 2 },
  weatherCity: { fontSize: 12, color: G.warm, letterSpacing: 1, textTransform: 'uppercase' },
  weatherExtra: { fontSize: 11, color: G.muted, marginTop: 2 },

  section: { paddingHorizontal: 16, paddingTop: 8 },
  sectionSub: {
    fontSize: 11, color: G.muted, letterSpacing: 2,
    textTransform: 'uppercase', marginBottom: 14, fontFamily: 'DMSans',
  },

  occasionGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 16 },
  occCard: {
    width: '31%', backgroundColor: G.card, borderRadius: 16,
    padding: 14, alignItems: 'center', borderWidth: 1.5, borderColor: G.border,
  },
  occCardActive: { borderColor: G.warm, backgroundColor: G.soft },
  occIcon: { fontSize: 26, marginBottom: 6 },
  occLabel: { fontSize: 10, color: G.muted, textAlign: 'center', fontFamily: 'DMSans' },

  input: {
    borderWidth: 1.5, borderColor: G.border, borderRadius: 12,
    paddingHorizontal: 16, paddingVertical: 14, fontSize: 15,
    backgroundColor: G.card, color: G.accent, marginBottom: 16, fontFamily: 'DMSans',
  },

  tipCard: {
    margin: 16, backgroundColor: G.soft, borderRadius: 16, padding: 20,
  },
  tipTitle: { fontSize: 13, color: G.muted, marginBottom: 8, fontFamily: 'DMSans' },
  tipText: { fontSize: 14, color: G.accent, lineHeight: 22 },
  tipBtn: {
    marginTop: 12, backgroundColor: G.warm,
    borderRadius: 10, paddingVertical: 10, paddingHorizontal: 16,
    alignSelf: 'flex-start',
  },
  tipBtnText: { color: '#fff', fontSize: 13, fontWeight: '500', fontFamily: 'DMSans' },
});
