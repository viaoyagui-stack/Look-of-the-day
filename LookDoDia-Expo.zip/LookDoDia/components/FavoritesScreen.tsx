import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { G } from '../constants';
import { ColorSwatch, EmptyState } from '../components/UI';
import { FavoriteEntry, HistoryEntry } from '../constants/types';

interface FavoritesProps {
  favorites: FavoriteEntry[];
  history: HistoryEntry[];
}

export default function FavoritesScreen({ favorites, history }: FavoritesProps) {
  const insets = useSafeAreaInsets();
  const [tab, setTab] = useState<'favs' | 'history'>('favs');

  return (
    <View style={{ flex: 1, backgroundColor: G.bg }}>
      <LinearGradient
        colors={[G.accent, '#2c2c2e']}
        style={[styles.header, { paddingTop: insets.top + 16 }]}
      >
        <Text style={styles.headerTitle}>Memória de estilo</Text>
        <View style={styles.tabs}>
          {(['favs', 'history'] as const).map(t => (
            <TouchableOpacity
              key={t}
              style={[styles.tab, tab === t && styles.tabActive]}
              onPress={() => setTab(t)}
            >
              <Text style={[styles.tabText, tab === t && styles.tabTextActive]}>
                {t === 'favs' ? '❤️ Favoritos' : '🕐 Histórico'}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </LinearGradient>

      <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 100 }}>
        {tab === 'favs' && (
          favorites.length === 0
            ? <EmptyState icon="🤍" title="Sem favoritos" subtitle="Favorite looks na tela de sugestões para vê-los aqui." />
            : favorites.map((fav, i) => (
              <View key={i} style={styles.card}>
                <Text style={styles.cardDate}>
                  ❤️ {new Date(fav.date).toLocaleDateString('pt-BR', { day: '2-digit', month: 'long' })}
                </Text>
                <Text style={styles.cardOccasion}>{fav.occasion}</Text>
                <View style={styles.pieces}>
                  {[fav.look.top, fav.look.bottom, fav.look.shoes, fav.look.accessory]
                    .filter(Boolean)
                    .map((p: any, j) => (
                      <View key={j} style={styles.pieceChip}>
                        <ColorSwatch color={p.color} size={10} />
                        <Text style={styles.pieceChipText}>{p.nome || p.name}</Text>
                      </View>
                    ))}
                </View>
                {fav.look.motivo && (
                  <Text style={styles.motivo}>{fav.look.motivo}</Text>
                )}
              </View>
            ))
        )}

        {tab === 'history' && (
          history.length === 0
            ? <EmptyState icon="🕐" title="Sem histórico" subtitle="Seus looks gerados aparecerão aqui." />
            : [...history].reverse().map((h, i) => (
              <View key={i} style={styles.card}>
                <Text style={styles.cardDate}>
                  {new Date(h.date).toLocaleDateString('pt-BR', { weekday: 'long', day: '2-digit', month: 'long' })}
                </Text>
                <Text style={styles.cardOccasion}>{h.occasion}</Text>
                <Text style={styles.cardSub}>{h.looks?.length ?? 0} looks gerados</Text>
              </View>
            ))
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  header: { paddingHorizontal: 24, paddingBottom: 20 },
  headerTitle: { fontFamily: 'CormorantGaramond', fontSize: 32, fontWeight: '300', color: '#fff', marginBottom: 20 },
  tabs: {
    flexDirection: 'row', backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 12, padding: 3,
  },
  tab: { flex: 1, paddingVertical: 10, alignItems: 'center', borderRadius: 10 },
  tabActive: { backgroundColor: '#fff' },
  tabText: { fontSize: 13, color: 'rgba(255,255,255,0.6)', fontFamily: 'DMSans' },
  tabTextActive: { color: G.accent, fontWeight: '500' },

  card: {
    backgroundColor: G.card, borderRadius: 16,
    padding: 16, marginBottom: 12, borderWidth: 1, borderColor: G.border,
  },
  cardDate: { fontSize: 11, color: G.warm, letterSpacing: 1, textTransform: 'uppercase', marginBottom: 6, fontFamily: 'DMSans' },
  cardOccasion: { fontSize: 15, fontWeight: '500', color: G.accent, marginBottom: 8, fontFamily: 'DMSans' },
  cardSub: { fontSize: 12, color: G.muted },
  pieces: { flexDirection: 'row', flexWrap: 'wrap', gap: 6 },
  pieceChip: {
    flexDirection: 'row', alignItems: 'center', gap: 5,
    backgroundColor: G.soft, borderRadius: 8,
    paddingHorizontal: 10, paddingVertical: 6,
  },
  pieceChipText: { fontSize: 11, color: G.accent, fontFamily: 'DMSans' },
  motivo: { fontSize: 12, color: G.muted, marginTop: 10, lineHeight: 18, fontFamily: 'DMSans' },
});
