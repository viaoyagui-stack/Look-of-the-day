import React from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { G } from '../constants';
import { Button } from '../components/UI';
import { Profile } from '../constants/types';

interface ProfileScreenProps {
  profile: Profile;
  onEdit: () => void;
}

export default function ProfileScreen({ profile, onEdit }: ProfileScreenProps) {
  const insets = useSafeAreaInsets();
  const initial = profile.name?.charAt(0)?.toUpperCase() ?? '?';

  const prefs = [
    { label: 'Estilo preferido',        val: profile.style },
    { label: 'Sensibilidade climática', val: profile.sensitivity },
    { label: 'Cores favoritas',         val: profile.favColors.join(', ') || '—' },
    { label: 'Cores que evita',         val: profile.avoidColors.join(', ') || '—' },
  ];

  return (
    <ScrollView style={{ flex: 1, backgroundColor: G.bg }} contentContainerStyle={{ paddingBottom: 100 }}>
      <LinearGradient
        colors={[G.accent, '#2c2c2e']}
        style={[styles.header, { paddingTop: insets.top + 24 }]}
      >
        <View style={styles.avatar}>
          <Text style={styles.avatarText}>{initial}</Text>
        </View>
        <Text style={styles.name}>{profile.name}</Text>
        <Text style={styles.city}>📍 {profile.city}</Text>
      </LinearGradient>

      <View style={{ paddingTop: 16 }}>
        {prefs.map(({ label, val }) => (
          <View key={label} style={styles.prefCard}>
            <Text style={styles.prefLabel}>{label}</Text>
            <Text style={styles.prefVal}>{val}</Text>
          </View>
        ))}
        <View style={{ paddingHorizontal: 16, marginTop: 8 }}>
          <Button label="Editar perfil" variant="outline" onPress={onEdit} />
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  header: { paddingHorizontal: 24, paddingBottom: 32 },
  avatar: {
    width: 72, height: 72, borderRadius: 36,
    backgroundColor: G.warm, alignItems: 'center', justifyContent: 'center',
    marginBottom: 16,
  },
  avatarText: { fontFamily: 'CormorantGaramond', fontSize: 32, color: '#fff' },
  name: { fontFamily: 'CormorantGaramond', fontSize: 28, fontWeight: '300', color: '#fff' },
  city: { fontSize: 13, color: 'rgba(255,255,255,0.5)', marginTop: 4 },

  prefCard: {
    backgroundColor: G.card, borderRadius: 16,
    padding: 18, marginHorizontal: 16, marginBottom: 12,
    borderWidth: 1, borderColor: G.border,
  },
  prefLabel: { fontSize: 11, color: G.muted, letterSpacing: 1, textTransform: 'uppercase', marginBottom: 6, fontFamily: 'DMSans' },
  prefVal: { fontSize: 15, color: G.accent, fontFamily: 'DMSans' },
});
