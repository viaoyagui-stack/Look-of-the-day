import React from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, ScrollView,
  ActivityIndicator, ViewStyle, TextStyle,
} from 'react-native';
import { G, COLOR_HEX } from '../constants';

// ─── COLOR SWATCH ─────────────────────────────────────────────────────────────
export function ColorSwatch({ color, size = 12 }: { color: string; size?: number }) {
  return (
    <View style={{
      width: size, height: size, borderRadius: size / 2,
      backgroundColor: COLOR_HEX[color] ?? '#ccc',
      borderWidth: 1, borderColor: 'rgba(0,0,0,0.1)',
    }} />
  );
}

// ─── CHIP ─────────────────────────────────────────────────────────────────────
interface ChipProps {
  label: string;
  selected: boolean;
  onPress: () => void;
  warn?: boolean;
}
export function Chip({ label, selected, onPress, warn }: ChipProps) {
  return (
    <TouchableOpacity
      onPress={onPress}
      style={[
        styles.chip,
        selected && styles.chipSelected,
        warn && !selected && styles.chipWarn,
        warn && selected && styles.chipWarnSelected,
      ]}
    >
      <Text style={[
        styles.chipText,
        selected && styles.chipTextSelected,
        warn && !selected && styles.chipTextWarn,
      ]}>
        {label}
      </Text>
    </TouchableOpacity>
  );
}

// ─── CHIP GROUP ───────────────────────────────────────────────────────────────
interface ChipGroupProps {
  options: string[];
  value: string | string[];
  onChange: (val: any) => void;
  multi?: boolean;
  warn?: boolean;
}
export function ChipGroup({ options, value, onChange, multi = false, warn = false }: ChipGroupProps) {
  const toggle = (o: string) => {
    if (!multi) {
      onChange(o === value ? '' : o);
      return;
    }
    const arr = Array.isArray(value) ? value : [];
    onChange(arr.includes(o) ? arr.filter(x => x !== o) : [...arr, o]);
  };
  const isSelected = (o: string) =>
    multi ? (Array.isArray(value) && value.includes(o)) : value === o;

  return (
    <View style={styles.chipGroup}>
      {options.map(o => (
        <Chip key={o} label={o} selected={isSelected(o)} onPress={() => toggle(o)} warn={warn} />
      ))}
    </View>
  );
}

// ─── BUTTON ───────────────────────────────────────────────────────────────────
interface ButtonProps {
  label: string;
  onPress: () => void;
  variant?: 'dark' | 'outline' | 'warm';
  disabled?: boolean;
  style?: ViewStyle;
}
export function Button({ label, onPress, variant = 'dark', disabled, style }: ButtonProps) {
  return (
    <TouchableOpacity
      onPress={onPress}
      disabled={disabled}
      style={[
        styles.btn,
        variant === 'dark'    && styles.btnDark,
        variant === 'outline' && styles.btnOutline,
        variant === 'warm'    && styles.btnWarm,
        disabled && { opacity: 0.4 },
        style,
      ]}
    >
      <Text style={[
        styles.btnText,
        variant === 'outline' && { color: G.accent },
      ]}>
        {label}
      </Text>
    </TouchableOpacity>
  );
}

// ─── LOADING ──────────────────────────────────────────────────────────────────
export function LoadingView({ text = 'Carregando…' }: { text?: string }) {
  return (
    <View style={styles.loading}>
      <ActivityIndicator size="large" color={G.warm} />
      <Text style={styles.loadingText}>{text}</Text>
    </View>
  );
}

// ─── EMPTY STATE ──────────────────────────────────────────────────────────────
export function EmptyState({ icon, title, subtitle }: { icon: string; title: string; subtitle?: string }) {
  return (
    <View style={styles.empty}>
      <Text style={styles.emptyIcon}>{icon}</Text>
      <Text style={styles.emptyTitle}>{title}</Text>
      {subtitle && <Text style={styles.emptySub}>{subtitle}</Text>}
    </View>
  );
}

// ─── SECTION LABEL ────────────────────────────────────────────────────────────
export function SectionLabel({ children }: { children: string }) {
  return <Text style={styles.sectionLabel}>{children}</Text>;
}

// ─── STYLES ───────────────────────────────────────────────────────────────────
const styles = StyleSheet.create({
  chip: {
    paddingHorizontal: 14, paddingVertical: 8,
    borderRadius: 50, borderWidth: 1.5, borderColor: G.border,
    backgroundColor: G.card, marginRight: 6, marginBottom: 6,
  },
  chipSelected: { backgroundColor: G.accent, borderColor: G.accent },
  chipWarn: { backgroundColor: '#FFF3E0', borderColor: '#FFB74D' },
  chipWarnSelected: { backgroundColor: '#E65100', borderColor: '#E65100' },
  chipText: { fontSize: 13, color: G.accent, fontFamily: 'DMSans' },
  chipTextSelected: { color: '#fff' },
  chipTextWarn: { color: '#E65100' },
  chipGroup: { flexDirection: 'row', flexWrap: 'wrap', marginBottom: 8 },

  btn: {
    paddingVertical: 16, borderRadius: 14,
    alignItems: 'center', justifyContent: 'center',
  },
  btnDark: { backgroundColor: G.accent },
  btnOutline: { borderWidth: 1.5, borderColor: G.border, backgroundColor: 'transparent' },
  btnWarm: { backgroundColor: G.warm },
  btnText: { fontSize: 15, fontWeight: '500', color: '#fff', fontFamily: 'DMSans' },

  loading: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 16, padding: 40 },
  loadingText: { fontSize: 18, color: G.muted, fontFamily: 'CormorantGaramond' },

  empty: { alignItems: 'center', padding: 60 },
  emptyIcon: { fontSize: 48, marginBottom: 16 },
  emptyTitle: { fontSize: 24, fontFamily: 'CormorantGaramond', marginBottom: 8, color: G.accent },
  emptySub: { fontSize: 14, color: G.muted, textAlign: 'center', lineHeight: 22 },

  sectionLabel: {
    fontSize: 11, letterSpacing: 2, textTransform: 'uppercase',
    color: G.muted, marginBottom: 12, fontFamily: 'DMSans',
  },
});
