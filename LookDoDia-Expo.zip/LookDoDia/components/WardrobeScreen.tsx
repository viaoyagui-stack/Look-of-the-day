import React, { useState } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity, StyleSheet,
  TextInput, Modal, FlatList,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { G, CATEGORIES, COLORS, FORMALITY, CLIMATES, COLOR_HEX, CAT_EMOJI } from '../constants';
import { ChipGroup, SectionLabel, Button } from '../components/UI';
import { Piece } from '../constants/types';

interface WardrobeProps {
  wardrobe: Piece[];
  setWardrobe: (w: Piece[]) => void;
}

const EMPTY_FORM = { name: '', category: 'Camiseta', color: 'Branco', formality: 'Casual', climate: [] as string[] };

export default function WardrobeScreen({ wardrobe, setWardrobe }: WardrobeProps) {
  const insets = useSafeAreaInsets();
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState({ ...EMPTY_FORM });
  const [filter, setFilter] = useState('Todos');
  const set = (k: string, v: any) => setForm(p => ({ ...p, [k]: v }));

  const addPiece = () => {
    if (!form.name.trim()) return;
    const piece: Piece = { ...form, id: Date.now().toString() };
    setWardrobe([...wardrobe, piece]);
    setForm({ ...EMPTY_FORM });
    setShowAdd(false);
  };

  const removePiece = (id: string) => setWardrobe(wardrobe.filter(p => p.id !== id));
  const filtered = filter === 'Todos' ? wardrobe : wardrobe.filter(p => p.category === filter);

  return (
    <View style={{ flex: 1, backgroundColor: G.bg }}>
      <LinearGradient
        colors={[G.accent, '#2c2c2e']}
        style={[styles.header, { paddingTop: insets.top + 16 }]}
      >
        <View>
          <Text style={styles.headerTitle}>Guarda-roupa</Text>
          <Text style={styles.headerSub}>{wardrobe.length} {wardrobe.length === 1 ? 'peça' : 'peças'}</Text>
        </View>
        <TouchableOpacity style={styles.addBtn} onPress={() => setShowAdd(true)}>
          <Text style={styles.addBtnText}>+ Adicionar</Text>
        </TouchableOpacity>
      </LinearGradient>

      {/* Filter chips */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false}
        style={{ maxHeight: 56 }} contentContainerStyle={styles.filterRow}>
        {['Todos', ...CATEGORIES].map(c => (
          <TouchableOpacity
            key={c}
            style={[styles.filterChip, filter === c && styles.filterChipActive]}
            onPress={() => setFilter(c)}
          >
            <Text style={[styles.filterChipText, filter === c && { color: '#fff' }]}>{c}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {filtered.length === 0 ? (
        <View style={styles.empty}>
          <Text style={styles.emptyIcon}>👗</Text>
          <Text style={styles.emptyTitle}>{filter === 'Todos' ? 'Guarda-roupa vazio' : 'Nenhuma peça aqui'}</Text>
          <Text style={styles.emptySub}>{filter === 'Todos' ? 'Adicione suas roupas para receber looks personalizados.' : 'Tente outro filtro.'}</Text>
        </View>
      ) : (
        <FlatList
          data={filtered}
          numColumns={2}
          keyExtractor={i => i.id}
          contentContainerStyle={{ padding: 12, paddingBottom: 100 }}
          columnWrapperStyle={{ gap: 12 }}
          ItemSeparatorComponent={() => <View style={{ height: 12 }} />}
          renderItem={({ item: p }) => (
            <View style={styles.pieceCard}>
              <View style={[styles.colorBar, { backgroundColor: COLOR_HEX[p.color] ?? '#eee' }]}>
                <Text style={{ fontSize: 32 }}>{CAT_EMOJI[p.category] ?? '👕'}</Text>
              </View>
              <View style={styles.pieceInfo}>
                <Text style={styles.pieceName} numberOfLines={1}>{p.name}</Text>
                <Text style={styles.pieceCat}>{p.category}</Text>
                <View style={styles.pieceTags}>
                  <Text style={styles.pieceTag}>{p.formality}</Text>
                  {p.climate.map(c => <Text key={c} style={styles.pieceTag}>{c}</Text>)}
                </View>
                <TouchableOpacity onPress={() => removePiece(p.id)} style={{ marginTop: 6 }}>
                  <Text style={{ fontSize: 11, color: G.muted }}>🗑 remover</Text>
                </TouchableOpacity>
              </View>
            </View>
          )}
        />
      )}

      {/* Add Sheet */}
      <Modal visible={showAdd} animationType="slide" transparent>
        <TouchableOpacity
          style={styles.overlay}
          activeOpacity={1}
          onPress={() => setShowAdd(false)}
        >
          <TouchableOpacity activeOpacity={1} style={styles.sheet}>
            <View style={styles.sheetHandle} />
            <ScrollView contentContainerStyle={{ paddingBottom: 40 }}>
              <Text style={styles.sheetTitle}>Nova peça</Text>

              <Text style={styles.label}>Nome da peça *</Text>
              <TextInput
                style={styles.input}
                placeholder="Ex: Camisa azul listrada"
                placeholderTextColor={G.muted}
                value={form.name}
                onChangeText={v => set('name', v)}
              />

              <Text style={styles.label}>Categoria</Text>
              <ChipGroup options={CATEGORIES} value={form.category} onChange={v => set('category', v)} />

              <Text style={styles.label}>Cor</Text>
              <ChipGroup options={COLORS} value={form.color} onChange={v => set('color', v)} />

              <Text style={styles.label}>Formalidade</Text>
              <ChipGroup options={FORMALITY} value={form.formality} onChange={v => set('formality', v)} />

              <Text style={styles.label}>Clima ideal</Text>
              <ChipGroup options={CLIMATES} value={form.climate} onChange={v => set('climate', v)} multi />

              <Button
                label="Adicionar peça"
                onPress={addPiece}
                disabled={!form.name.trim()}
              />
            </ScrollView>
          </TouchableOpacity>
        </TouchableOpacity>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  header: {
    paddingHorizontal: 24, paddingBottom: 24,
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-end',
  },
  headerTitle: { fontFamily: 'CormorantGaramond', fontSize: 32, fontWeight: '300', color: '#fff' },
  headerSub: { fontSize: 13, color: 'rgba(255,255,255,0.5)', marginTop: 4 },
  addBtn: {
    backgroundColor: G.warm, borderRadius: 10,
    paddingHorizontal: 16, paddingVertical: 10,
  },
  addBtnText: { color: '#fff', fontSize: 13, fontWeight: '500', fontFamily: 'DMSans' },

  filterRow: { paddingHorizontal: 16, paddingVertical: 10, gap: 8, flexDirection: 'row' },
  filterChip: {
    paddingHorizontal: 14, paddingVertical: 8, borderRadius: 50,
    borderWidth: 1.5, borderColor: G.border, backgroundColor: G.card,
  },
  filterChipActive: { backgroundColor: G.accent, borderColor: G.accent },
  filterChipText: { fontSize: 12, color: G.accent, fontFamily: 'DMSans' },

  pieceCard: { flex: 1, backgroundColor: G.card, borderRadius: 16, overflow: 'hidden', borderWidth: 1, borderColor: G.border },
  colorBar: { height: 80, alignItems: 'center', justifyContent: 'center' },
  pieceInfo: { padding: 12 },
  pieceName: { fontSize: 13, fontWeight: '500', color: G.accent, marginBottom: 2, fontFamily: 'DMSans' },
  pieceCat: { fontSize: 11, color: G.muted, fontFamily: 'DMSans' },
  pieceTags: { flexDirection: 'row', flexWrap: 'wrap', gap: 4, marginTop: 6 },
  pieceTag: { fontSize: 9, backgroundColor: G.soft, paddingHorizontal: 6, paddingVertical: 2, borderRadius: 50, color: G.muted, fontFamily: 'DMSans' },

  empty: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 40 },
  emptyIcon: { fontSize: 48, marginBottom: 16 },
  emptyTitle: { fontFamily: 'CormorantGaramond', fontSize: 24, marginBottom: 8, color: G.accent },
  emptySub: { fontSize: 14, color: G.muted, textAlign: 'center', lineHeight: 22 },

  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  sheet: {
    backgroundColor: G.bg, borderTopLeftRadius: 24, borderTopRightRadius: 24,
    padding: 24, maxHeight: '90%',
  },
  sheetHandle: { width: 40, height: 4, backgroundColor: G.border, borderRadius: 2, alignSelf: 'center', marginBottom: 20 },
  sheetTitle: { fontFamily: 'CormorantGaramond', fontSize: 24, marginBottom: 20, color: G.accent },
  label: { fontSize: 12, color: G.muted, marginBottom: 8, fontFamily: 'DMSans' },
  input: {
    borderWidth: 1.5, borderColor: G.border, borderRadius: 12,
    paddingHorizontal: 16, paddingVertical: 14, fontSize: 15,
    backgroundColor: G.card, color: G.accent, marginBottom: 16, fontFamily: 'DMSans',
  },
});
