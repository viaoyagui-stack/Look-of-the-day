import { Profile, Piece, Weather, Look } from '../constants/types';

export async function generateLooks(
  profile: Profile,
  wardrobe: Piece[],
  occasion: string,
  weather: Weather | null
): Promise<{ looks: Look[] }> {
  const wardrobeDesc = wardrobe.length
    ? wardrobe.map(p =>
        `[ID:${p.id}] ${p.name} (${p.category}, cor:${p.color}, formalidade:${p.formality}, clima:${p.climate.join('/')})`
      ).join('\n')
    : 'Guarda-roupa vazio — sugira combinações genéricas sem IDs';

  const prompt = `Você é um stylist pessoal profissional. Sugira 3 looks completos para o usuário.

PERFIL:
- Nome: ${profile.name}
- Estilo: ${profile.style}
- Sensibilidade: ${profile.sensitivity}
- Cores favoritas: ${profile.favColors.join(', ')}
- Cores que evita: ${profile.avoidColors.join(', ')}

CLIMA ATUAL:
- Temperatura: ${weather?.temp ?? '?'}°C
- Condição: ${weather?.desc ?? 'Desconhecido'}
- Vento: ${weather?.wind ?? 0}km/h
- Chuva: ${weather?.rain ? 'Sim' : 'Não'}

OCASIÃO: ${occasion}

GUARDA-ROUPA (use os IDs exatos):
${wardrobeDesc}

RESPONDA APENAS com JSON válido (sem markdown), no formato:
{
  "looks": [
    {
      "numero": 1,
      "top": {"id":"ID_ou_null","nome":"nome","cor":"cor"},
      "bottom": {"id":"ID_ou_null","nome":"nome","cor":"cor"},
      "shoes": {"id":"ID_ou_null","nome":"nome","cor":"cor"},
      "accessory": {"id":"ID_ou_null","nome":"nome","cor":"cor"} ou null,
      "motivo": "explicação curta em 1-2 frases"
    }
  ]
}`;

  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 1000,
      messages: [{ role: 'user', content: prompt }],
    }),
  });

  const data = await res.json();
  const text = (data.content as Array<{ text?: string }>)
    ?.map(b => b.text ?? '')
    .join('') ?? '';

  const clean = text.replace(/```json|```/g, '').trim();
  return JSON.parse(clean);
}
