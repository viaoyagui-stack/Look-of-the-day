import { WEATHER_CODES } from '../constants';
import { Weather } from '../constants/types';

export async function fetchWeather(city: string): Promise<Weather | null> {
  try {
    const geoRes = await fetch(
      `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(city)}&count=1&language=pt&format=json`
    );
    const geoData = await geoRes.json();
    if (!geoData.results?.length) return null;

    const { latitude, longitude, name } = geoData.results[0];

    const wxRes = await fetch(
      `https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&current=temperature_2m,weathercode,windspeed_10m,precipitation&timezone=auto`
    );
    const wxData = await wxRes.json();
    const cur = wxData.current;

    return {
      temp: Math.round(cur.temperature_2m),
      code: cur.weathercode,
      wind: Math.round(cur.windspeed_10m),
      rain: cur.precipitation > 0,
      desc: WEATHER_CODES[cur.weathercode as number] ?? '☀️ Tempo variável',
      city: name,
    };
  } catch {
    return null;
  }
}
